Izwinqwam se no tezi domashni sam gi poglednal ot kolegi ...

Po skoro se izwinqwam na sebe si :)

