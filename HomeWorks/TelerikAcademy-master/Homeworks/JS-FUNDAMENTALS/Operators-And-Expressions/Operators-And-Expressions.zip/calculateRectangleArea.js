// Write an expression that calculates rectangle�s area
// by given width and height.

var width = 7, length = 9;

console.log(getArea(width, length));

function getArea(width, length){
    return width * length;
}