// Create a string variable with quoted text in it.
// For example: 'How you doin'?', Joey said.

var singleQuotes = '\'How you doin\'?\', Joey said.';
var doubleQuotes = "'How you doin'?', Joey said.";

var result = singleQuotes +'\n\r'+ doubleQuotes;

console.log(result);
